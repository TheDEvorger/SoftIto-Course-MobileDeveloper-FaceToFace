class BildirimModeli {
  final String id;
  final String baslik;
  final String icerik;
  final String tarih;
  final bool okundumu;

  const BildirimModeli({
    required this.id,
    required this.baslik,
    required this.icerik,
    required this.tarih,
    this.okundumu = false,
  });

  BildirimModeli copyWith({
    String? id,
    String? baslik,
    String? icerik,
    String? tarih,
    bool? okundumu,
  }) {
    return BildirimModeli(
      id: id ?? this.id,
      baslik: baslik ?? this.baslik,
      icerik: icerik ?? this.icerik,
      tarih: tarih ?? this.tarih,
      okundumu: okundumu ?? this.okundumu,
    );
  }
}
