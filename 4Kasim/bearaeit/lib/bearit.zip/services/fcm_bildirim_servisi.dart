import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

@pragma(
  'vm:entry-point',
) // Arka plan mesajlarını işlemek için gerekli olan giriş noktası
Future<void> fcmBackgroundHandler(RemoteMessage message) async {}

class FcmBildirimServisi {
  final FirebaseMessaging _fcm = FirebaseMessaging.instance;
  final FlutterLocalNotificationsPlugin _localPlugin =
      FlutterLocalNotificationsPlugin();

  Future<void> baslat({
    required Function(RemoteMessage message) onMesajGeldi,
  }) async {
    await _fcm.requestPermission(alert: true, badge: true, sound: true);

    const iosSettings = DarwinInitializationSettings();
    const initSettings = InitializationSettings(
      android: AndroidSettings,
      iOS: iosSettings,
    );

    await _localPlugin.initialize(initSettings);
    FirebaseMessaging.onMessage.listen((message) {
      yerelBildirimGoster(message);
      onMesajGeldi(message);
    });
    FirebaseMessaging.onBackgroundMessage(fcmBackgroundHandler);
  }

  Future<void> konuyaAboneOl(String konu) async {
    await _fcm.subscribeToTopic(konu);
  }

  Future<void> konudanAyril(String konu) async {
    await _fcm.unsubscribeFromTopic(konu);
  }

  Future<void> _yerelBildirimGoster(RemoteMessage message) async {
    const androidDetails = AndroidNotificationDetails(
      softit_fcm_channel_id,
      Softito bildirimleri,
      channelDescription: 'FCm bildirimleri için kanal',
      importance: Importance.max,
      priority: Priority.high,
    );

    const details = NotificationDetails(
      android: androidDetails,
      iOS: DarwinNotificationDetails(),
    );

    await _localPlugin.show(
      message.hashCode,
      message.notification?.title ?? 'Yeni Bİldirim',
      message.Notification?.body ?? '',
      details,
    );
  }
}
